import React, { useCallback, useEffect, useState } from 'react';
import Card from './Cards';
import "../css/card.css"

const USERS_PER_PAGE = 5;

const Dashboard = () => {
  const [users, setUsers] = useState([]);
  const [page, setPage] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
  const [nextdis, setnextdis] = useState(false)
  const [filterUser, setfilterUser] = useState([])

  const fetchUsers = async (currentPage) => {
    const start = (currentPage) * USERS_PER_PAGE;
    console.log(start)
    const res = await fetch(`https://jsonplaceholder.typicode.com/users?_start=${start}&_limit=${USERS_PER_PAGE}`);
    const data = await res.json();
    if (data.length == 0) {
      setnextdis(true)
    }
    let copy = [...users, ...data]
    setPage(page + 1)
    setUsers(copy)
  };

  useEffect(() => {
    fetchUsers(0)
  }, [])


  const handlePrevious = useCallback(() => {
    if (page >= 1) {
      setPage(page - 1)
      setnextdis(false)
    }
  }, [page]);

  const handleNext = useCallback(() => {
    if (users.length > USERS_PER_PAGE * page) {
      fetchUsers(page)
    } else {
      fetchUsers(page)
    }
  }, [page]);

  const filteredUsers = useCallback((e) => {
    setSearchTerm(e.target.value)
    console.log(e)
    if (searchTerm.length == 1) {
      setfilterUser([])
    } else {
      let filtered = users.filter((user) => {
        return user.name.toLowerCase().includes(searchTerm)
      })
      console.log(filtered)
      setfilterUser(filtered)
    }

  }, [filterUser, users])

  return (
    <div className="dashboard-cont">
      <h2>Dashboard</h2>
      <input
        className="form-control"
        type="text"
        placeholder="Search by name..."
        value={searchTerm}
        style={{ width: "60%" }}
        onChange={(e) => filteredUsers(e)}
      />
      <div className="users-cont" style={{ width: '60%', height: 'auto', display: 'flex' }}>
        {filterUser.length <= 0 ? (users && users.map((user, index) => {
          if ((page - 1) * USERS_PER_PAGE <= index && index < page * USERS_PER_PAGE) {
            return <Card user={user} />
          }
        })) : (
          filterUser.map((user) => {
            return <Card user={user} />
          })
        )}
      </div>
      <div className="d-flex justify-content-center mt-3">
        <button className="btn btn-primary me-2" onClick={handlePrevious} disabled={page <= 1}>Previous</button>
        <button className="btn btn-primary" onClick={handleNext} disabled={nextdis}>Next</button>
      </div>
    </div>
  );
};

export default Dashboard;

