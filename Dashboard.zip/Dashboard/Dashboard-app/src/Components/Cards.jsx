import React from 'react';
import "../css/card.css"

const Card = ({user}) => {
  return (
    <>
    <div className="d-flex align-items-center justify-content-center border border-black mx-3 my-3" style={{width: "300px", height: "150px"}}>
      <div className="d-flex flex-column align-items-center justify-content-evenly p-4" style={{ width: '95%', height: '95%' }}>
        <div>Name: {user.name}</div>
        <div>UserName: {user.username}</div>
        <div>Email: {user.email}</div>
        <div>Phone: {user.phone}</div>
      </div>
    </div>
    </>
  );
};

export default Card;
